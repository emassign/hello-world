package modifications;

use strict;

sub process_localisation
{
	my (%Modification_Details);
	my ($Modified_Sequence,$Protein,$Methyl_all_prb,$Methyl4_all_prb,$Methyl_prb,$Dimethyl_prb,$Trimethyl_prb,$Methyl4_prb,$Dimethyl4_prb,$Trimethyl4_prb,$Oxidation_prb,$Met4_prb,$Met4ox_prb,$prbLcPrb_Min,$fasta,$Mod_Window) = (@_);

	# extract informations on modification positions that have been assigned by MQ
	my (%Assigned_Modification_Positions) = &mod_positions_on_peptide($Modified_Sequence);
	my ($Protein_Position)	 = &determine_protein_position_of_peptide($Modified_Sequence,$Protein,$fasta);
	
	my (%Probabilities) = (
								Methyl_all	=> {sequence => $$Methyl_all_prb, type => "me", state => "L"},								
								Methyl4_all	=> {sequence => $$Methyl4_all_prb,type => "me", state => "H"},
								Methyl		=> {sequence => $$Methyl_prb, 	  type => "me", state => "L"},
								Dimethyl	=> {sequence => $$Dimethyl_prb,   type => "di", state => "L"},
								Trimethyl	=> {sequence => $$Trimethyl_prb,  type => "tr", state => "L"},								
								Methyl4		=> {sequence => $$Methyl4_prb, 	  type => "me", state => "H"},
								Dimethyl4	=> {sequence => $$Dimethyl4_prb,  type => "di", state => "H"},
								Trimethyl4	=> {sequence => $$Trimethyl4_prb, type => "tr", state => "H"},
								Oxidation	=> {sequence => $$Oxidation_prb,  type => "ox", state => "L"},
								Met4		=> {sequence => $$Met4_prb,  	  type => "me", state => "H"},
								Met4ox		=> {sequence => $$Met4ox_prb,  	  type => "ox", state => "H"}
					      );
						  
	foreach my $Modification_Type (sort keys %Probabilities)
	{
		my $Prb_Sequence = $Probabilities{$Modification_Type}{'sequence'};
		my $Prb_Type	 = $Probabilities{$Modification_Type}{'type'};
		my $Prb_State	 = $Probabilities{$Modification_Type}{'state'};
		
		next if (!defined($Prb_Sequence) || $Prb_Sequence =~ /^$/);

		my ($Char,$Offset,$Desc_Offset)	= ('(',0,0);
		my ($Mod_Desc_Offset);
		my $Prb_Index = index($Prb_Sequence, $Char, $Offset);
	
		while ($Prb_Index != -1)
		{		
			my $Prb_Pos 						= ($Prb_Index - $Desc_Offset);
			my $Prb_Value_Region				= substr($Prb_Sequence,$Prb_Index+1,6);
			my ($Prb_Value,$Prb_Value_Offset)	= &trim_prb_value($Prb_Value_Region); #because probability 'string' has variable length
			my $Prb_AA							= substr($Prb_Sequence,$Prb_Index-1,1);		
						
			# REMOVE MODIFICATION ANNOTATION FROM SEQUENCE IF IT IS ASSIGNED WITH LOW CONFIDENCE
			if ($Prb_Value < $$prbLcPrb_Min && exists($Assigned_Modification_Positions{$Prb_AA}{$Prb_Type}{$Prb_Pos}))
			{
					$Mod_Desc_Offset += 4;
					$Modification_Details{'AMBIGUOUS'}{$Prb_AA}{$Prb_Type}{$Prb_Pos}{'state'} = $Prb_State;
			}
			# LOW PROBABILITY MODIFICATIONS THAT WERE NOT SELECTED BY MQ (CAN IGNORE THESE)
			elsif ($Prb_Value < $$prbLcPrb_Min && !exists($Assigned_Modification_Positions{$Prb_AA}{$Prb_Type}{$Prb_Pos}))
			{
					$Modification_Details{'UNASSIGNED'}{$Prb_AA}{$Prb_Type}{$Prb_Pos}{'state'} = $Prb_State;
			}
			# MODIFICATIONS ASSIGNED WITH HIGH CONFIDENCE
			elsif ($Prb_Value >= $$prbLcPrb_Min && exists($Assigned_Modification_Positions{$Prb_AA}{$Prb_Type}{$Prb_Pos}))
			{
				$Modification_Details{'GOOD'}{$Prb_AA}{$Prb_Type}{$Prb_Pos}{'state'} = $Prb_State;
				$Mod_Desc_Offset += 4;
			}
			# THESE ARE CONFIDENTLY ASSIGNED MODIFICATIONS THAT WERE NOT INCLUDED BY MAXQUANT (IF THESE EXIST, I HAVE NO EXPLANATION AT TIME OF CODING)
			elsif ($Prb_Value >= $$prbLcPrb_Min && !exists($Assigned_Modification_Positions{$Prb_AA}{$Prb_Type}{$Prb_Pos}))
			{
				$Modification_Details{'UNASSIGNED_CHECK_THIS'}{$Prb_AA}{$Prb_Type}{$Prb_Pos}{'state'} = $Prb_State;
			}
			
			$Desc_Offset += (2 + $Prb_Value_Offset);
			$Offset		 = $Prb_Index + 1;
			$Prb_Index	 = index($Prb_Sequence, $Char, $Offset);			
		}
	}

	my $Modification_Summary = &determine_sequence_windows_and_residue_numbers(\%Modification_Details,$Protein,$Protein_Position,$Mod_Window,$fasta);
	
	return($Modification_Summary);
}

sub mod_positions_on_peptide
{
	my (%Modification_Positions);
	my ($Modified_Sequence) = (@_);
	my ($Char,$Offset,$Desc_Offset)	= ('(',0,0);
	
	$$Modified_Sequence =~ s/\_//g;
	$$Modified_Sequence =~ s/\(ac\)//g;
	
	my $Mod_Index = index($$Modified_Sequence, $Char, $Offset);

	while ($Mod_Index != -1)
	{	
		my $Mod_Pos 	= ($Mod_Index - $Desc_Offset);
		my $Mod_Desc	= substr($$Modified_Sequence,$Mod_Index+1,2);
		my $Mod_AA		= substr($$Modified_Sequence,$Mod_Index-1,1);
		
		$Modification_Positions{$Mod_AA}{$Mod_Desc}{$Mod_Pos} = 0;
		
		$Desc_Offset += 4;
		$Offset		 = $Mod_Index + 1;
		$Mod_Index	 = index($$Modified_Sequence, $Char, $Offset);
	}
	return(%Modification_Positions);
}

sub trim_prb_value
{
	my ($Prb_Value_Region) = (@_);
	my ($Prb_Value,$Prb_Value_Region_Offset);
	
	if ($Prb_Value_Region =~ /^1\)\S*$/)
	{
		($Prb_Value,$Prb_Value_Region_Offset) = (1,1);
	}
	elsif ($Prb_Value_Region =~ /^0\)\S*$/)
	{
		($Prb_Value,$Prb_Value_Region_Offset) = (1,1);
	}
	elsif ($Prb_Value_Region =~ /(^\d{1}\.\d+)\)\S*$/)
	{
		($Prb_Value) = ($1);
		($Prb_Value_Region_Offset) = length($1);
	}
	
	return($Prb_Value,$Prb_Value_Region_Offset);
}

sub determine_protein_position_of_peptide
{
	my ($modified_sequence,$protein_identifier,$fasta) = (@_);

	my ($modified_sequence_local) = $$modified_sequence; 
	my ($leading_identifier)	  = $$protein_identifier;
	
	($leading_identifier) = ($1) if ($leading_identifier =~ /^(\w+)\;*/);
	$modified_sequence_local      =~ s/\_//g;
	$modified_sequence_local      =~ s/\(\w{2}\)//g;
	$modified_sequence_local      =~ s/\I|L/X/g;
	#	sp|P23246|SFPQ_HUMAN
	my ($reference_sequence)	  = $$fasta{$leading_identifier}{'IL_cleaned'};
	my ($protein_position)		  = index($reference_sequence,$modified_sequence_local);
	
	return (\$protein_position);
}

sub determine_sequence_windows_and_residue_numbers
{
	my ($modification_ref,$protein,$protein_position_ref,$sequence_window_size,$fasta) = (@_);

	my ($leading_identifier)	 = $$protein;
	($leading_identifier) = ($1) if ($leading_identifier =~ /^(\w+)\;*/);
	
	my $buffer = 'z' x $$sequence_window_size;
	my $sequence = $buffer.$$fasta{$leading_identifier}{'Raw'}.$buffer;

	my (%modifications) = %{$modification_ref};

	foreach my $confidence (keys %modifications)
	{
		foreach my $mod_aa (keys %{$modifications{$confidence}})
		{
			foreach my $mod_desc (keys %{$modifications{$confidence}{$mod_aa}})
			{				
				foreach my $mod_pos (keys %{$modifications{$confidence}{$mod_aa}{$mod_desc}})
				{
					my $residue_number = $mod_pos + $$protein_position_ref;
					my $window_start   = ($$sequence_window_size+$residue_number-(($$sequence_window_size-1)/2));	
					my $mod_window	   = substr($sequence,$window_start-1,$$sequence_window_size);
					
					$modifications{$confidence}{$mod_aa}{$mod_desc}{$mod_pos}{'residue'}	= $residue_number;
					$modifications{$confidence}{$mod_aa}{$mod_desc}{$mod_pos}{'window'}		= $mod_window;				
				}
			}
		}
	}

	return (\%modifications);
}

1;