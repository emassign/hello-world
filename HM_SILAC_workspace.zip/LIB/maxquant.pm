package maxquant;

use strict;

# Extract column names
sub columns
{
	my (%file);
	my ($column_ref) = (@_);
	my ($index) = (0);
	
	foreach my $col (@{$column_ref})
	{
		if ($col !~ /^$/)
		{			
			$file{$col} = $index;
			$index++;
		}
	}
	return (\%file)
}

sub read_and_clean_fasta
{
	my ($database) = (@_);
	my (%fasta_database,$protein_identifier);
	
	open FASTA, $$database or die "COULD NOT LOCATE SEQUENCE DATABASE";
	foreach my $line (<FASTA>)
	{
		chomp($line);	
		$line =~ s/\s+//g;
		
		if ($line =~ /^\>\w+\|(.*)\|.*/)
		{
			($protein_identifier) = ($1);
		}
		else
		{
			$fasta_database{$protein_identifier}{'Raw'} .= $line;
			$line =~ s/\I|L/X/g; #to ignore issue of Leucine/Isoleucine descrimination by mass spec during mapping
			$fasta_database{$protein_identifier}{'IL_cleaned'} .= $line;
		}
	}
	close FASTA;
	
	return (\%fasta_database);
}

sub print_header_redundant
{
	my $line;
	
	$line .=  "State\t";
	$line .=  "Dataset\t";
	$line .=  "Evidence ID\t";
	$line .=  "Modified sequence\t";
	$line .=  "Modification Window\t";
	$line .=  "Missed cleavages\t";
	$line .=  "Leading Proteins\t";
	$line .=  "Gene Names\t";
	$line .=  "Residue\t";
	$line .=  "Modification\t";
	$line .=  "Position in protein\t";
	$line .=  "PEP\t";
	$line .=  "Score\t";
	$line .=  "Delta score\t";
	$line .=  "Experiment\t";
	$line .=  "Raw file\t";
	$line .=  "m/z\t";
	$line .=  "Intensity\t";
	$line .=  "Retention time\t";
	$line .=  "MS/MS Scan Number\t";
	$line .=  "Best MS/MS ID\t";
	$line .=  "Peak Coverage\t";
	$line .=  "Sequence\t";
	$line .=  "Charge\t";
	$line .=  "Peak List\t";
	$line .=  "Peak List [Corrected]\t";
	$line .=  "Delta Mass\tProtein Names";

	return $line;
}


sub print_header_nr
{
	my $line;
	
	$line .=  "Sequence\t";
	$line .=  "Missed Cleavages\t";
	$line .=  "Modified Sequence\t";
	$line .=  "Protein\t";
	$line .=  "Gene\t";
	$line .=  "Modification\t";
	$line .=  "Modification Window\t";
	$line .=  "Exp H\t";
	$line .=  "Raw H\t";
	$line .=  "MSMSID H\t";
	$line .=  "Score H\t";
	$line .=  "Exp L\t";
	$line .=  "Raw L\t";
	$line .=  "MSMSID L\t";
	$line .=  "Score L";

	return $line;
}


1;